package cs250.hw3;

import java.io.*;    
import java.net.*;
import java.io.IOException;
import java.util.Random;

public class TCPServer {
    static DataInputStream[] din = new DataInputStream[2];
    static DataOutputStream[] dout = new DataOutputStream[2]; 
    static Socket[] clientSocket = new Socket[2];
    static ServerSocket serverSocket;
    

    public static int receiveNum(int index){
        try {
            int response = din[index].readInt();
            return response;
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

        return -1;
    }

    public static void sendNumber(int numToSend, int index){
        try {
            dout[index].writeInt(numToSend);
            dout[index].flush(); // By flushing the stream, it means to clear the stream of any element that may be or maybe not inside the stream
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

    }

    public static void cleanUp(){
        try {
            serverSocket.close();
            for (int i = 0; i <2; ++i){
            clientSocket[i].close();
            dout[i].close();
            din[i].close();
            }
            System.out.println("Connections Closed");
            System.exit(0);

        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }


    public static void main(String[] args){

         // Validate
        if (args.length != 3) {
            System.err.println("Error: Expected 3 args <port-number> <seed> <number-of-messages>");
            System.exit(1);
        }
        
        final int port = Integer.parseInt(args[0]); 
        final int seed = Integer.parseInt(args[1]);
        final int numMsg = Integer.parseInt(args[2]);

        // port validation
        try{
           if(port <= 1024 || port > 65535){throw new IllegalArgumentException();}
        }catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
            System.exit(1);
        }
        

        try{
            InetAddress local = InetAddress.getLocalHost();
            System.out.println("IP Address: " + local.getHostName() + "/" + local.getHostAddress());
            System.out.println("Port Number " + port);  

            // Initialize Necessary Objects
            serverSocket = new ServerSocket(port);
            System.out.println("waiting for client...");

            clientSocket[0] = serverSocket.accept(); // Blocking call --> waits here until a request comes in from a client
            clientSocket[1] = serverSocket.accept();
            System.out.println("Client Connected!");

        //Initalize streams
            dout[0] = new DataOutputStream(clientSocket[0].getOutputStream()); // Instantiates dout so we can then use it to send data to the client
            din[0] = new DataInputStream(clientSocket[0].getInputStream());
            dout[1] = new DataOutputStream(clientSocket[1].getOutputStream());
            din[1] = new DataInputStream(clientSocket[1].getInputStream()); // Instantiates din so we can then use it to receive data from the client

        // Generate random numbers for each client
            Random rand = new Random(seed);
            int clientSeed0 = rand.nextInt();
            int clientSeed1 = rand.nextInt();

            // Send # of messages and rand seed

            //First Client
            System.out.println("Sending config to clients...");
            sendNumber(numMsg, 0);
            sendNumber(clientSeed0, 0);
            System.out.println(clientSocket[0].getInetAddress().getHostName() + " " + clientSeed0);

            //Second Client
            sendNumber(numMsg, 1);
            sendNumber(clientSeed1, 1);
            System.out.println(clientSocket[1].getInetAddress().getHostName() + " " + clientSeed1); 

            System.out.println("Finished sending config to clients.");
        }
        catch(IOException e){
            System.err.println(e.getMessage());
        }
    }



}
