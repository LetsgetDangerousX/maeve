package cs250.hw3;

import java.io.*;    
import java.net.*;
import java.io.IOException;


public class TCPClient {
    static DataInputStream din;
    static DataOutputStream dout;
    static Socket clientSocket;

    public static int receiveNum(){
        try { 
            return din.readInt();
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
        return -1; // if an incorrect value is read, the EXIT_NUM will be returned
    }

    public static void sendNumber(int numToSend){
        try {
            dout.writeInt(numToSend); // Writes an int to the output stream
            dout.flush(); // By flushing the stream, it means to clear the stream of any element that may be or maybe not inside the stream
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

    }
    
    // Below method cleans up all of the connections by closing them and then exiting. 
    // This prevents a lot of problems, so its good practice to always make sure the connections close. 

    public static void cleanUp(){
        try {
            clientSocket.close();
            dout.close();
            din.close();
            System.exit(0);

        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    public static void main(String[] args){
        final String server_ip = args[0]; 
        final int port =  Integer.parseInt(args[1]);
        

        try{

            // Initialize Necessary Objects
            clientSocket = new Socket(server_ip, port); // Establishes a connection to the server
            dout = new DataOutputStream(clientSocket.getOutputStream()); // Instantiates out so we can then use it to send data to the client
            din = new DataInputStream(clientSocket.getInputStream()); // Instantiates in so we can then use it to receive data from the client
            
            //Receive config
            int numMsg = receiveNum();
            int seed = receiveNum();

            // ouput 
            System.out.println("Received config");
            System.out.println("number of messages = " + numMsg);
            System.out.println("seed = " + seed);

            cleanUp();
        }
        catch(IOException e){
            System.err.println(e.getMessage());
        }
    }
}
